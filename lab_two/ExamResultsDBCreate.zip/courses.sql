set search_path to "examresultsdb";
INSERT INTO examresultsdb.courses (courseid,coursename,professor) VALUES
	 (1,'themselves','Dr. Rhonda Brown'),
	 (2,'cause','Dr. Derek Navarro'),
	 (3,'himself','Dr. Jason Robinson'),
	 (4,'it','Dr. Lori Collins'),
	 (5,'beat','Dr. Matthew Douglas'),
	 (6,'any','Dr. April Bowman'),
	 (7,'himself','Dr. Daniel Dyer'),
	 (8,'popular','Dr. Shawn Cummings'),
	 (9,'detail','Dr. Aaron Phillips'),
	 (10,'work','Dr. Mark Mitchell');
