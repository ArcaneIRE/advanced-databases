
set search_path to "examresultsdb";
INSERT INTO examresultsdb.students (studentid,firstname,lastname,dateofbirth,email) VALUES
	 (1,'Gina','Gray','2006-04-01','Gina.Gray@exuni.ie'),
	 (2,'Cristian','Khan','2001-08-22','Cristian.Khan@exuni.ie'),
	 (3,'George','Villanueva','2003-04-11','George.Villanueva@exuni.ie'),
	 (4,'Robert','Solis','2000-04-28','Robert.Solis@exuni.ie'),
	 (5,'Amy','Rojas','2005-12-21','Amy.Rojas@exuni.ie'),
	 (6,'Henry','Douglas','2001-06-10','Henry.Douglas@exuni.ie'),
	 (7,'Robert','Mooney','2002-08-20','Robert.Mooney@exuni.ie'),
	 (8,'Alejandra','Thomas','2005-02-16','Alejandra.Thomas@exuni.ie'),
	 (9,'Holly','Giles','1999-09-05','Holly.Giles@exuni.ie'),
	 (10,'Nicholas','Beck','2005-08-02','Nicholas.Beck@exuni.ie');
INSERT INTO examresultsdb.students (studentid,firstname,lastname,dateofbirth,email) VALUES
	 (11,'April','Young','2002-10-05','April.Young@exuni.ie'),
	 (12,'Brian','Mitchell','2003-09-18','Brian.Mitchell@exuni.ie'),
	 (13,'Lori','Baker','2000-09-14','Lori.Baker@exuni.ie'),
	 (14,'Carol','Haas','2003-02-26','Carol.Haas@exuni.ie'),
	 (15,'Michael','Blackburn','2001-02-10','Michael.Blackburn@exuni.ie'),
	 (16,'Nathaniel','Welch','2000-04-29','Nathaniel.Welch@exuni.ie'),
	 (17,'Joshua','Davis','2003-11-10','Joshua.Davis@exuni.ie'),
	 (18,'Mary','Mitchell','2000-07-18','Mary.Mitchell@exuni.ie'),
	 (19,'Christopher','Campbell','1999-08-09','Christopher.Campbell@exuni.ie'),
	 (20,'Karen','Taylor','2000-06-18','Karen.Taylor@exuni.ie');
INSERT INTO examresultsdb.students (studentid,firstname,lastname,dateofbirth,email) VALUES
	 (21,'Nicholas','Smith','2002-01-15','Nicholas.Smith@exuni.ie'),
	 (22,'Jeff','Sanchez','2004-08-21','Jeff.Sanchez@exuni.ie'),
	 (23,'Justin','Lee','2003-12-01','Justin.Lee@exuni.ie'),
	 (24,'James','Acosta','2006-08-22','James.Acosta@exuni.ie'),
	 (25,'Thomas','Landry','2005-02-27','Thomas.Landry@exuni.ie'),
	 (26,'Heather','Green','2003-01-26','Heather.Green@exuni.ie'),
	 (27,'Steven','Anderson','1998-11-05','Steven.Anderson@exuni.ie'),
	 (28,'Jessica','Lewis','2005-02-16','Jessica.Lewis@exuni.ie'),
	 (29,'Don','Brown','1999-04-12','Don.Brown@exuni.ie'),
	 (30,'Shane','Mitchell','1998-11-08','Shane.Mitchell@exuni.ie');
INSERT INTO examresultsdb.students (studentid,firstname,lastname,dateofbirth,email) VALUES
	 (31,'Sandra','Jones','2000-08-27','Sandra.Jones@exuni.ie'),
	 (32,'Yvette','Rodriguez','2001-06-28','Yvette.Rodriguez@exuni.ie'),
	 (33,'Stephen','Dodson','2000-12-10','Stephen.Dodson@exuni.ie'),
	 (34,'Alexis','Reed','2004-03-28','Alexis.Reed@exuni.ie'),
	 (35,'Kyle','Schroeder','2003-10-20','Kyle.Schroeder@exuni.ie'),
	 (36,'Joyce','Gonzalez','1999-03-05','Joyce.Gonzalez@exuni.ie'),
	 (37,'Ana','Hurley','2003-08-14','Ana.Hurley@exuni.ie'),
	 (38,'Amanda','Scott','2000-09-08','Amanda.Scott@exuni.ie'),
	 (39,'Makayla','Mann','2003-06-18','Makayla.Mann@exuni.ie'),
	 (40,'Clarence','Todd','2001-04-27','Clarence.Todd@exuni.ie');
INSERT INTO examresultsdb.students (studentid,firstname,lastname,dateofbirth,email) VALUES
	 (41,'Melissa','Cunningham','2001-08-12','Melissa.Cunningham@exuni.ie'),
	 (42,'Martha','Adams','1999-06-07','Martha.Adams@exuni.ie'),
	 (43,'Taylor','Patel','2006-07-02','Taylor.Patel@exuni.ie'),
	 (44,'Colton','Page','2005-02-07','Colton.Page@exuni.ie'),
	 (45,'Robert','Escobar','2004-02-10','Robert.Escobar@exuni.ie'),
	 (46,'Cheryl','White','2004-07-26','Cheryl.White@exuni.ie'),
	 (47,'Randy','Casey','1999-04-23','Randy.Casey@exuni.ie'),
	 (48,'Frank','Payne','2005-06-06','Frank.Payne@exuni.ie'),
	 (49,'David','Hansen','1999-01-10','David.Hansen@exuni.ie'),
	 (50,'Randall','Gaines','2004-07-04','Randall.Gaines@exuni.ie');
INSERT INTO examresultsdb.students (studentid,firstname,lastname,dateofbirth,email) VALUES
	 (51,'Troy','Schmidt','2002-12-22','Troy.Schmidt@exuni.ie'),
	 (52,'Julie','Nguyen','2002-05-19','Julie.Nguyen@exuni.ie'),
	 (53,'Sarah','Williams','2005-08-27','Sarah.Williams@exuni.ie'),
	 (54,'Lauren','Dickson','2004-10-25','Lauren.Dickson@exuni.ie'),
	 (55,'Andre','Quinn','2002-04-12','Andre.Quinn@exuni.ie'),
	 (56,'Stephanie','Dyer','2001-02-19','Stephanie.Dyer@exuni.ie'),
	 (57,'Cynthia','Nguyen','2004-09-29','Cynthia.Nguyen@exuni.ie'),
	 (58,'Danny','Alexander','1998-11-02','Danny.Alexander@exuni.ie'),
	 (59,'Mary','Santiago','2001-05-30','Mary.Santiago@exuni.ie'),
	 (60,'Trevor','Clay','1998-11-20','Trevor.Clay@exuni.ie');
INSERT INTO examresultsdb.students (studentid,firstname,lastname,dateofbirth,email) VALUES
	 (61,'Brandy','Cox','2004-01-13','Brandy.Cox@exuni.ie'),
	 (62,'Michelle','Arnold','1998-11-22','Michelle.Arnold@exuni.ie'),
	 (63,'Michelle','Marsh','2005-02-22','Michelle.Marsh@exuni.ie'),
	 (64,'Russell','Johnson','2006-02-23','Russell.Johnson@exuni.ie'),
	 (65,'Rachel','Allen','1999-10-09','Rachel.Allen@exuni.ie'),
	 (66,'Tiffany','Foster','2005-09-04','Tiffany.Foster@exuni.ie'),
	 (67,'Paula','Gonzalez','2001-10-31','Paula.Gonzalez@exuni.ie'),
	 (68,'Bryan','Miles','2005-11-28','Bryan.Miles@exuni.ie'),
	 (69,'Peter','Mcclain','2005-01-04','Peter.Mcclain@exuni.ie'),
	 (70,'James','Nichols','1999-10-12','James.Nichols@exuni.ie');
INSERT INTO examresultsdb.students (studentid,firstname,lastname,dateofbirth,email) VALUES
	 (71,'Monica','Cherry','2001-01-06','Monica.Cherry@exuni.ie'),
	 (72,'Richard','Powell','2000-06-13','Richard.Powell@exuni.ie'),
	 (73,'Angela','Fuentes','2005-12-04','Angela.Fuentes@exuni.ie'),
	 (74,'Elizabeth','Smith','2004-11-17','Elizabeth.Smith@exuni.ie'),
	 (75,'Mary','Lee','2006-07-30','Mary.Lee@exuni.ie'),
	 (76,'Robert','Stein','2001-07-22','Robert.Stein@exuni.ie'),
	 (77,'Ashley','Thompson','2000-07-05','Ashley.Thompson@exuni.ie'),
	 (78,'Marcus','Johnson','2000-12-21','Marcus.Johnson@exuni.ie'),
	 (79,'Brandon','Kennedy','2001-04-21','Brandon.Kennedy@exuni.ie'),
	 (80,'Jennifer','Sosa','2003-11-26','Jennifer.Sosa@exuni.ie');
INSERT INTO examresultsdb.students (studentid,firstname,lastname,dateofbirth,email) VALUES
	 (81,'Adrian','Harris','1999-05-23','Adrian.Harris@exuni.ie'),
	 (82,'Michael','Fox','2006-06-19','Michael.Fox@exuni.ie'),
	 (83,'James','Chandler','2000-10-22','James.Chandler@exuni.ie'),
	 (84,'Ricky','Cohen','2002-11-12','Ricky.Cohen@exuni.ie'),
	 (85,'Jason','Ibarra','2005-10-12','Jason.Ibarra@exuni.ie'),
	 (86,'Alexa','Jones','2003-03-25','Alexa.Jones@exuni.ie'),
	 (87,'Scott','Williamson','2006-07-26','Scott.Williamson@exuni.ie'),
	 (88,'Matthew','Roberts','2000-02-10','Matthew.Roberts@exuni.ie'),
	 (89,'Leslie','Parker','2000-10-21','Leslie.Parker@exuni.ie'),
	 (90,'Jennifer','Deleon','2005-05-09','Jennifer.Deleon@exuni.ie');
INSERT INTO examresultsdb.students (studentid,firstname,lastname,dateofbirth,email) VALUES
	 (91,'Ashley','Harper','2002-05-15','Ashley.Harper@exuni.ie'),
	 (92,'Robert','Clark','1999-06-07','Robert.Clark@exuni.ie'),
	 (93,'Jerry','Potter','2003-03-01','Jerry.Potter@exuni.ie'),
	 (94,'Wendy','Johns','2005-12-07','Wendy.Johns@exuni.ie'),
	 (95,'Amanda','Olsen','2005-06-04','Amanda.Olsen@exuni.ie'),
	 (96,'Michelle','Palmer','1999-08-30','Michelle.Palmer@exuni.ie'),
	 (97,'Karen','Carter','2003-08-13','Karen.Carter@exuni.ie'),
	 (98,'Frank','Hart','2000-04-25','Frank.Hart@exuni.ie'),
	 (99,'Catherine','Taylor','2002-09-14','Catherine.Taylor@exuni.ie'),
	 (100,'Erica','Collins','2002-03-25','Erica.Collins@exuni.ie');
