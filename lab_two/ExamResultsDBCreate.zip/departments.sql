set search_path to "examresultsdb";
INSERT INTO examresultsdb.departments (deptid,deptname) VALUES
	 (1,'term'),
	 (2,'pretty'),
	 (3,'court'),
	 (4,'just'),
	 (5,'early'),
	 (6,'face'),
	 (7,'sing'),
	 (8,'the'),
	 (9,'two'),
	 (10,'wind');
